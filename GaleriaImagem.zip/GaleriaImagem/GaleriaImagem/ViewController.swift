//
//  ViewController.swift
//  GaleriaImagem
//
//  Created by Beatriz Andreucci on 10/06/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

