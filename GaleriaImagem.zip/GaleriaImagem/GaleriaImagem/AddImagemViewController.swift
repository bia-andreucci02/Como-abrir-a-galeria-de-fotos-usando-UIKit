//
//  AddImagemViewController.swift
//  GaleriaImagem
//
//  Created by Beatriz Andreucci on 10/06/24.
//

import UIKit

class AddImagemViewController: UIViewController, UIImagePickerControllerDelegate,  UINavigationControllerDelegate {
    
    let imageView: UIImageView = {
        let imageView = UIImageView()
        
        imageView.layer.cornerRadius = 20
        imageView.layer.borderWidth = 2.0;
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .lightGray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.clipsToBounds = true
        
        return imageView
    }()
    
    let buttonOpenGallery: UIButton = {
        let buttonOpenGallery = UIButton()
        
        buttonOpenGallery.setTitle("Adicionar foto", for: .normal)
        buttonOpenGallery.setTitleColor(.black, for: .normal)
        buttonOpenGallery.backgroundColor = .lightGray
        buttonOpenGallery.layer.cornerRadius = 10
        buttonOpenGallery.addTarget(self, action: #selector(btnOpenGallery_func), for:
                .touchUpInside) //button action para clicar e abrir a galeria
        buttonOpenGallery.translatesAutoresizingMaskIntoConstraints = false
        return buttonOpenGallery
    }()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        addImageView()
        addButton()
        
    }
    
    
    
    func addImageView(){
        view.addSubview (imageView)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 110),
            imageView.centerXAnchor.constraint (equalTo: view.centerXAnchor, constant: 0),
            imageView.heightAnchor.constraint(equalToConstant: 120),
            imageView.widthAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: 1),
        ])
    }
    
    func addButton(){
        view.addSubview(buttonOpenGallery)
        NSLayoutConstraint.activate([
        buttonOpenGallery.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
        buttonOpenGallery.widthAnchor.constraint(equalToConstant: 150),
        buttonOpenGallery.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
        ])
    }
    
    

    //adicionar
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.editedImage] as? UIImage {
            imageView.image = image
        }else if let image = info[.originalImage] as? UIImage {
            imageView.image = image
        }
            
        dismiss (animated: true)
    }//depois de selecionar
    
    @objc func btnOpenGallery_func(sender:UIButton) {
        //button action
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true)
    } //open image controller
    

    


}

#Preview() {
    return AddImagemViewController()
}
